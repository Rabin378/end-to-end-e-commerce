-- Revenue by product
SELECT
    product_id,
    product_name,
    category,
    SUM(total_amount) AS revenue,
    SUM(quantity) AS units_sold,
    COUNT(DISTINCT order_id) AS orders
FROM transactions
GROUP BY product_id, product_name, category
ORDER BY revenue DESC
LIMIT 20;

-- Most valuable customers
SELECT
    customer_id,
    customer_name,
    country,
    COUNT(DISTINCT order_id) AS orders,
    SUM(total_amount) AS lifetime_value,
    AVG(total_amount) AS avg_order_value,
    MAX(order_date) AS last_order_date
FROM transactions
GROUP BY customer_id, customer_name, country
ORDER BY lifetime_value DESC
LIMIT 20;

-- Monthly sales trend
SELECT
    strftime('%Y-%m', order_date) AS sales_month,
    SUM(total_amount) AS revenue,
    COUNT(DISTINCT order_id) AS orders,
    COUNT(DISTINCT customer_id) AS active_customers
FROM transactions
GROUP BY sales_month
ORDER BY sales_month;

-- Weekly sales trend
SELECT
    strftime('%Y-%W', order_date) AS sales_week,
    SUM(total_amount) AS revenue,
    COUNT(DISTINCT order_id) AS orders
FROM transactions
GROUP BY sales_week
ORDER BY sales_week;

