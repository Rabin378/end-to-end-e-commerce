from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def configure_plotting() -> None:
    try:
        import seaborn as sns

        sns.set_theme(style="whitegrid", palette="deep")
    except Exception:
        plt.style.use("ggplot")


def make_visualizations(
    monthly: pd.DataFrame,
    weekly: pd.DataFrame,
    products: pd.DataFrame,
    rfm: pd.DataFrame,
    churn: pd.DataFrame,
    forecast: pd.DataFrame,
    figures_dir: Path,
) -> dict[str, Path]:
    configure_plotting()
    figures_dir.mkdir(parents=True, exist_ok=True)

    paths = {
        "monthly_revenue": figures_dir / "monthly_revenue.png",
        "weekly_forecast": figures_dir / "weekly_sales_forecast.png",
        "top_products": figures_dir / "top_products.png",
        "segments": figures_dir / "customer_segments.png",
        "churn": figures_dir / "churn_risk_distribution.png",
    }

    plot_monthly_revenue(monthly, paths["monthly_revenue"])
    plot_weekly_forecast(weekly, forecast, paths["weekly_forecast"])
    plot_top_products(products.head(10), paths["top_products"])
    plot_segments(rfm, paths["segments"])
    plot_churn(churn, paths["churn"])
    return paths


def plot_monthly_revenue(monthly: pd.DataFrame, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(monthly["period"], monthly["revenue"], marker="o", linewidth=2)
    ax.set_title("Monthly Revenue Trend")
    ax.set_xlabel("Month")
    ax.set_ylabel("Revenue")
    ax.tick_params(axis="x", rotation=65)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_weekly_forecast(weekly: pd.DataFrame, forecast: pd.DataFrame, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(pd.to_datetime(weekly["week_start"]), weekly["revenue"], label="Actual revenue", linewidth=2)
    ax.plot(pd.to_datetime(forecast["week_start"]), forecast["forecast_revenue"], label="Forecast", linewidth=2)
    ax.fill_between(
        pd.to_datetime(forecast["week_start"]),
        forecast["lower_estimate"],
        forecast["upper_estimate"],
        alpha=0.18,
        label="Forecast range",
    )
    ax.set_title("Weekly Sales Forecast")
    ax.set_xlabel("Week")
    ax.set_ylabel("Revenue")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_top_products(products: pd.DataFrame, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10, 6))
    labels = products["product_name"].str.replace(" Item ", " ", regex=False)
    ax.barh(labels[::-1], products["revenue"][::-1])
    ax.set_title("Top Products by Revenue")
    ax.set_xlabel("Revenue")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_segments(rfm: pd.DataFrame, path: Path) -> None:
    counts = rfm["segment"].value_counts().sort_values()
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(counts.index, counts.values)
    ax.set_title("Customer Segments")
    ax.set_xlabel("Customers")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_churn(churn: pd.DataFrame, path: Path) -> None:
    counts = churn["churn_risk"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(counts.index, counts.values)
    ax.set_title("Churn Risk Distribution")
    ax.set_xlabel("Risk level")
    ax.set_ylabel("Customers")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)

