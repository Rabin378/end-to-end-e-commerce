from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def build_churn_dataset(rfm: pd.DataFrame) -> pd.DataFrame:
    data = rfm.copy()
    recency_threshold = float(data["recency_days"].quantile(0.72))
    frequency_threshold = float(data["frequency"].median())
    data["churned"] = np.where(
        (data["recency_days"] >= recency_threshold)
        & ((data["frequency"] <= frequency_threshold) | (data["orders_per_90_days"] < 0.9)),
        1,
        0,
    )
    return data


def train_churn_model(rfm: pd.DataFrame, models_dir: Path) -> tuple[pd.DataFrame, dict]:
    data = build_churn_dataset(rfm)
    features = [
        "recency_days",
        "frequency",
        "monetary",
        "avg_order_value",
        "categories_purchased",
        "discount_share",
        "orders_per_90_days",
    ]
    X = data[features].astype(float)
    y = data["churned"].astype(int)

    try:
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score
        from sklearn.model_selection import train_test_split

        stratify = y if y.nunique() > 1 and y.value_counts().min() > 1 else None
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=stratify
        )
        model = RandomForestClassifier(n_estimators=160, min_samples_leaf=4, random_state=42)
        model.fit(X_train, y_train)
        probabilities = model.predict_proba(X)[:, 1]
        test_probabilities = model.predict_proba(X_test)[:, 1]
        test_predictions = (test_probabilities >= 0.5).astype(int)
        metrics = {
            "model": "RandomForestClassifier",
            "accuracy": round(float(accuracy_score(y_test, test_predictions)), 3),
            "precision": round(float(precision_score(y_test, test_predictions, zero_division=0)), 3),
            "recall": round(float(recall_score(y_test, test_predictions, zero_division=0)), 3),
            "roc_auc": round(float(roc_auc_score(y_test, test_probabilities)), 3) if y_test.nunique() > 1 else None,
            "fallback_used": False,
        }
    except Exception as exc:
        probabilities = heuristic_churn_probability(data)
        predictions = (probabilities >= 0.5).astype(int)
        metrics = binary_metrics(y.to_numpy(), predictions, probabilities)
        metrics["model"] = "Heuristic fallback - install scikit-learn for RandomForestClassifier"
        metrics["fallback_used"] = True
        metrics["fallback_reason"] = str(exc)

    result = data.copy()
    result["churn_probability"] = probabilities
    result["churn_risk"] = pd.cut(
        result["churn_probability"],
        bins=[-0.01, 0.35, 0.65, 1.01],
        labels=["Low", "Medium", "High"],
    ).astype(str)
    result = result.sort_values(["churn_probability", "monetary"], ascending=[False, False]).reset_index(drop=True)

    models_dir.mkdir(parents=True, exist_ok=True)
    (models_dir / "churn_model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return result, metrics


def heuristic_churn_probability(data: pd.DataFrame) -> np.ndarray:
    recency = minmax(data["recency_days"])
    low_frequency = 1 - minmax(data["frequency"])
    low_velocity = 1 - minmax(data["orders_per_90_days"])
    discount = minmax(data["discount_share"])
    probability = 0.48 * recency + 0.22 * low_frequency + 0.22 * low_velocity + 0.08 * discount
    return np.clip(probability.to_numpy(), 0, 1)


def minmax(series: pd.Series) -> pd.Series:
    low = float(series.min())
    high = float(series.max())
    if high == low:
        return pd.Series(0.0, index=series.index)
    return (series - low) / (high - low)


def binary_metrics(y_true: np.ndarray, y_pred: np.ndarray, probabilities: np.ndarray) -> dict:
    accuracy = float((y_true == y_pred).mean())
    true_positive = float(((y_true == 1) & (y_pred == 1)).sum())
    false_positive = float(((y_true == 0) & (y_pred == 1)).sum())
    false_negative = float(((y_true == 1) & (y_pred == 0)).sum())
    precision = true_positive / (true_positive + false_positive) if true_positive + false_positive else 0.0
    recall = true_positive / (true_positive + false_negative) if true_positive + false_negative else 0.0
    return {
        "accuracy": round(accuracy, 3),
        "precision": round(precision, 3),
        "recall": round(recall, 3),
        "roc_auc": approximate_auc(y_true, probabilities),
    }


def approximate_auc(y_true: np.ndarray, probabilities: np.ndarray) -> float | None:
    positive = probabilities[y_true == 1]
    negative = probabilities[y_true == 0]
    if len(positive) == 0 or len(negative) == 0:
        return None
    comparisons = [(p > n) + 0.5 * (p == n) for p in positive for n in negative]
    return round(float(np.mean(comparisons)), 3)


def forecast_weekly_sales(weekly_sales: pd.DataFrame, horizon_weeks: int = 12) -> tuple[pd.DataFrame, dict]:
    series = weekly_sales.copy()
    series = series.sort_values("week_start").reset_index(drop=True)
    series["time_index"] = np.arange(len(series))
    series["month"] = pd.to_datetime(series["week_start"]).dt.month

    feature_columns = ["time_index"]
    seasonal = pd.get_dummies(series["month"], prefix="month", drop_first=True, dtype=float)
    X = pd.concat([series[feature_columns], seasonal], axis=1)
    y = series["revenue"].astype(float)

    train_size = max(8, int(len(series) * 0.82))
    X_train, X_test = X.iloc[:train_size], X.iloc[train_size:]
    y_train, y_test = y.iloc[:train_size], y.iloc[train_size:]

    try:
        from sklearn.linear_model import LinearRegression
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

        model = LinearRegression()
        model.fit(X_train, y_train)
        test_pred = model.predict(X_test) if len(X_test) else np.array([])
        metrics = {
            "model": "LinearRegression with monthly seasonality",
            "mae": round(float(mean_absolute_error(y_test, test_pred)), 2) if len(X_test) else None,
            "rmse": round(float(mean_squared_error(y_test, test_pred) ** 0.5), 2) if len(X_test) else None,
            "r2": round(float(r2_score(y_test, test_pred)), 3) if len(X_test) > 1 else None,
            "fallback_used": False,
        }

        future = make_future_features(series, seasonal.columns, horizon_weeks)
        forecast_values = model.predict(future[X.columns])
    except Exception as exc:
        coefficients = np.polyfit(X_train["time_index"], y_train, deg=1)
        test_pred = np.polyval(coefficients, X_test["time_index"]) if len(X_test) else np.array([])
        metrics = regression_metrics(y_test.to_numpy(), test_pred)
        metrics["model"] = "NumPy linear trend fallback - install scikit-learn for LinearRegression"
        metrics["fallback_used"] = True
        metrics["fallback_reason"] = str(exc)

        future = make_future_features(series, seasonal.columns, horizon_weeks)
        forecast_values = np.polyval(coefficients, future["time_index"])

    forecast = future[["week_start"]].copy()
    forecast["forecast_revenue"] = np.maximum(forecast_values, 0).round(2)
    forecast["lower_estimate"] = (forecast["forecast_revenue"] * 0.88).round(2)
    forecast["upper_estimate"] = (forecast["forecast_revenue"] * 1.12).round(2)
    return forecast, metrics


def make_future_features(series: pd.DataFrame, seasonal_columns: pd.Index, horizon_weeks: int) -> pd.DataFrame:
    last_week = pd.to_datetime(series["week_start"].max())
    future_weeks = pd.date_range(last_week + pd.Timedelta(days=7), periods=horizon_weeks, freq="W-MON")
    future = pd.DataFrame({"week_start": future_weeks, "time_index": np.arange(len(series), len(series) + horizon_weeks)})
    future["month"] = future["week_start"].dt.month
    future_seasonal = pd.get_dummies(future["month"], prefix="month", drop_first=True, dtype=float)
    for column in seasonal_columns:
        if column not in future_seasonal:
            future_seasonal[column] = 0.0
    future = pd.concat([future, future_seasonal[list(seasonal_columns)]], axis=1)
    return future


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    if len(y_true) == 0:
        return {"mae": None, "rmse": None, "r2": None}
    error = y_true - y_pred
    mae = float(np.mean(np.abs(error)))
    rmse = float(np.sqrt(np.mean(error**2)))
    denominator = float(np.sum((y_true - np.mean(y_true)) ** 2))
    r2 = 1 - float(np.sum(error**2)) / denominator if denominator else None
    return {"mae": round(mae, 2), "rmse": round(rmse, 2), "r2": round(r2, 3) if r2 is not None else None}

