from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


def write_csv_outputs(
    reports_dir: Path,
    top_customers: pd.DataFrame,
    products: pd.DataFrame,
    rfm: pd.DataFrame,
    churn: pd.DataFrame,
    monthly: pd.DataFrame,
    weekly: pd.DataFrame,
    forecast: pd.DataFrame,
) -> None:
    reports_dir.mkdir(parents=True, exist_ok=True)
    top_customersuccessfully s.to_csv(reports_dir / "top_customers.csv", index=False)
    products.head(30).to_csv(reports_dir / "top_products.csv", index=False)
    rfm.to_csv(reports_dir / "customer_segments.csv", index=False)
    churn.head(100).to_csv(reports_dir / "churn_risk_customers.csv", index=False)
    monthly.to_csv(reports_dir / "monthly_sales_trend.csv", index=False)
    weekly.to_csv(reports_dir / "weekly_sales_trend.csv", index=False)
    forecast.to_csv(reports_dir / "sales_forecast.csv", index=False)


def write_summary_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def write_html_report(
    path: Path,
    metrics: dict,
    cleaning_audit: dict,
    churn_metrics: dict,
    forecast_metrics: dict,
    top_customers: pd.DataFrame,
    top_products: pd.DataFrame,
    rfm: pd.DataFrame,
    forecast: pd.DataFrame,
    figure_paths: dict[str, Path],
) -> None:
    segment_summary = (
        rfm.groupby(["segment", "promotion_recommendation"])
        .agg(customers=("customer_id", "count"), revenue=("monetary", "sum"))
        .reset_index()
        .sort_values("revenue", ascending=False)
    )
    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>E-Commerce Customer Intelligence Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 32px; color: #1f2933; line-height: 1.45; }}
    h1, h2 {{ color: #102a43; }}
    .grid {{ display: grid; grid-template-columns: repeat(4, minmax(150px, 1fr)); gap: 12px; }}
    .metric {{ border: 1px solid #d9e2ec; border-radius: 6px; padding: 14px; background: #f8fafc; }}
    .metric strong {{ display: block; font-size: 22px; color: #0b5cab; }}
    table {{ border-collapse: collapse; width: 100%; margin: 12px 0 26px; font-size: 14px; }}
    th, td {{ border: 1px solid #d9e2ec; padding: 8px; text-align: left; }}
    th {{ background: #eef2f7; }}
    img {{ max-width: 100%; border: 1px solid #d9e2ec; border-radius: 6px; margin: 8px 0 22px; }}
    .note {{ background: #fff8e6; border-left: 4px solid #f0b429; padding: 12px; }}
  </style>
</head>
<body>
  <h1>E-Commerce Customer Intelligence and Sales Forecasting</h1>
  <p class="note">This report converts raw transaction data into decisions for retention, merchandising, promotions, and sales planning.</p>

  <h2>Executive Metrics</h2>
  <section class="grid">
    <div class="metric"><span>Total Revenue</span><strong>${metrics["total_revenue"]:,.0f}</strong></div>
    <div class="metric"><span>Orders</span><strong>{metrics["total_orders"]:,}</strong></div>
    <div class="metric"><span>Customers</span><strong>{metrics["total_customers"]:,}</strong></div>
    <div class="metric"><span>Average Order Value</span><strong>${metrics["avg_order_value"]:,.0f}</strong></div>
  </section>

  <h2>Key Decisions</h2>
  <ul>
    <li>Prioritize <strong>{metrics["top_category"]}</strong>, the highest-revenue category.</li>
    <li>Feature <strong>{metrics["top_product"]}</strong>, the top product by revenue.</li>
    <li>Protect <strong>{metrics["at_risk_high_value_customers"]}</strong> high-value customers showing lapse behavior.</li>
    <li>Reward <strong>{metrics["champion_customers"]}</strong> champion customers with VIP treatment.</li>
  </ul>

  <h2>Data Quality</h2>
  {dict_to_table(cleaning_audit)}

  <h2>Top Customers</h2>
  {top_customers.head(10).to_html(index=False, float_format=lambda x: f"{x:,.2f}")}

  <h2>Top Products</h2>
  {top_products.head(10).to_html(index=False, float_format=lambda x: f"{x:,.2f}")}

  <h2>Customer Segments and Promotion Strategy</h2>
  {segment_summary.to_html(index=False, float_format=lambda x: f"{x:,.2f}")}

  <h2>Model Evaluation</h2>
  <h3>Churn Risk</h3>
  {dict_to_table(churn_metrics)}
  <h3>Sales Forecast</h3>
  {dict_to_table(forecast_metrics)}

  <h2>Sales Forecast</h2>
  {forecast.to_html(index=False, float_format=lambda x: f"{x:,.2f}")}

  <h2>Visual Analysis</h2>
  {image_tag(path, "Monthly revenue") if (path := figure_paths.get("monthly_revenue")) else ""}
  {image_tag(path, "Weekly forecast") if (path := figure_paths.get("weekly_forecast")) else ""}
  {image_tag(path, "Top products") if (path := figure_paths.get("top_products")) else ""}
  {image_tag(path, "Customer segments") if (path := figure_paths.get("segments")) else ""}
  {image_tag(path, "Churn risk") if (path := figure_paths.get("churn")) else ""}
</body>
</html>
"""
    path.write_text(html, encoding="utf-8")


def dict_to_table(values: dict) -> str:
    rows = "".join(f"<tr><th>{key}</th><td>{value}</td></tr>" for key, value in values.items())
    return f"<table>{rows}</table>"


def image_tag(path: Path, alt: str) -> str:
    relative = path.relative_to(path.parents[1])
    return f'<img src="{relative.as_posix()}" alt="{alt}">'

