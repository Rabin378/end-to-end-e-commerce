from __future__ import annotations

import numpy as np
import pandas as pd


def clean_transactions(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    before_rows = len(raw)
    df = raw.copy()
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    df["discount_rate"] = pd.to_numeric(df["discount_rate"], errors="coerce").fillna(0)

    duplicate_count = int(df.duplicated().sum())
    df = df.drop_duplicates()

    current_cutoff = pd.Timestamp("2026-01-01")
    invalid_mask = (
        df["order_date"].isna()
        | (df["order_date"] >= current_cutoff)
        | df["unit_price"].isna()
        | df["quantity"].isna()
        | (df["unit_price"] <= 0)
        | (df["quantity"] <= 0)
        | (df["discount_rate"] < 0)
        | (df["discount_rate"] >= 1)
    )
    invalid_rows = int(invalid_mask.sum())
    df = df.loc[~invalid_mask].copy()

    completed = df["order_status"].str.lower().eq("completed")
    non_completed_rows = int((~completed).sum())
    df = df.loc[completed].copy()

    df["quantity"] = df["quantity"].round().astype(int)
    df["total_amount"] = (df["unit_price"] * df["quantity"] * (1 - df["discount_rate"])).round(2)
    df["year_month"] = df["order_date"].dt.to_period("M").astype(str)
    df["year_week"] = df["order_date"].dt.strftime("%Y-%U")
    df["gross_amount"] = (df["unit_price"] * df["quantity"]).round(2)
    df["discount_amount"] = (df["gross_amount"] - df["total_amount"]).round(2)
    df["is_discounted"] = np.where(df["discount_rate"] > 0, 1, 0)

    df = df.sort_values(["order_date", "order_id"]).reset_index(drop=True)

    audit = {
        "raw_rows": before_rows,
        "duplicates_removed": duplicate_count,
        "invalid_rows_removed": invalid_rows,
        "non_completed_rows_removed": non_completed_rows,
        "clean_rows": int(len(df)),
        "date_min": str(df["order_date"].min().date()),
        "date_max": str(df["order_date"].max().date()),
    }
    return df, audit

