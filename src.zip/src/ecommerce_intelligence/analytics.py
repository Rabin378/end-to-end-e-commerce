from __future__ import annotations

import numpy as np
import pandas as pd


def rfm_analysis(clean_df: pd.DataFrame) -> pd.DataFrame:
    snapshot_date = clean_df["order_date"].max() + pd.Timedelta(days=1)
    rfm = (
        clean_df.groupby(["customer_id", "customer_name", "country"])
        .agg(
            recency_days=("order_date", lambda x: int((snapshot_date - x.max()).days)),
            frequency=("order_id", "nunique"),
            monetary=("total_amount", "sum"),
            avg_order_value=("total_amount", "mean"),
            categories_purchased=("category", "nunique"),
            discount_share=("is_discounted", "mean"),
            first_order=("order_date", "min"),
            last_order=("order_date", "max"),
        )
        .reset_index()
    )
    rfm["tenure_days"] = (snapshot_date - rfm["first_order"]).dt.days.clip(lower=1)
    rfm["orders_per_90_days"] = rfm["frequency"] / rfm["tenure_days"] * 90

    rfm["r_score"] = score_quantile(rfm["recency_days"], reverse=True)
    rfm["f_score"] = score_quantile(rfm["frequency"])
    rfm["m_score"] = score_quantile(rfm["monetary"])
    rfm["rfm_score"] = rfm["r_score"] + rfm["f_score"] + rfm["m_score"]
    rfm["segment"] = np.select(
        [
            (rfm["r_score"] >= 4) & (rfm["f_score"] >= 4) & (rfm["m_score"] >= 4),
            (rfm["r_score"] <= 2) & (rfm["m_score"] >= 4),
            (rfm["r_score"] >= 4) & (rfm["f_score"] <= 2),
            (rfm["r_score"] >= 3) & (rfm["m_score"] >= 3),
            (rfm["r_score"] <= 2) & (rfm["f_score"] <= 2),
        ],
        ["Champions", "At-Risk High Value", "New or Promising", "Loyal Growth", "Hibernating"],
        default="Needs Nurture",
    )
    rfm["promotion_recommendation"] = np.select(
        [
            rfm["segment"].eq("Champions"),
            rfm["segment"].eq("At-Risk High Value"),
            rfm["segment"].eq("New or Promising"),
            rfm["segment"].eq("Loyal Growth"),
            rfm["segment"].eq("Hibernating"),
        ],
        [
            "VIP early access and loyalty rewards",
            "Win-back offer with personal message",
            "Second-purchase discount and onboarding bundle",
            "Cross-sell based on favorite category",
            "Low-cost reactivation campaign",
        ],
        default="Educational email and light promotion",
    )
    return rfm.sort_values(["rfm_score", "monetary"], ascending=[False, False]).reset_index(drop=True)


def score_quantile(series: pd.Series, reverse: bool = False) -> pd.Series:
    ranked = series.rank(method="first")
    try:
        scored = pd.qcut(ranked, 5, labels=[1, 2, 3, 4, 5]).astype(int)
    except ValueError:
        scored = pd.Series(np.ceil(ranked / len(ranked) * 5), index=series.index).clip(1, 5).astype(int)
    if reverse:
        scored = 6 - scored
    return scored


def product_performance(clean_df: pd.DataFrame) -> pd.DataFrame:
    products = (
        clean_df.groupby(["product_id", "product_name", "category"])
        .agg(
            revenue=("total_amount", "sum"),
            units_sold=("quantity", "sum"),
            orders=("order_id", "nunique"),
            buyers=("customer_id", "nunique"),
            avg_discount=("discount_rate", "mean"),
        )
        .reset_index()
    )
    products["revenue_share"] = products["revenue"] / products["revenue"].sum()
    return products.sort_values("revenue", ascending=False).reset_index(drop=True)


def trend_tables(clean_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    monthly = (
        clean_df.groupby("year_month")
        .agg(revenue=("total_amount", "sum"), orders=("order_id", "nunique"), active_customers=("customer_id", "nunique"))
        .reset_index()
        .rename(columns={"year_month": "period"})
    )
    monthly["avg_order_value"] = monthly["revenue"] / monthly["orders"]
    monthly["revenue_growth"] = monthly["revenue"].pct_change().fillna(0)

    weekly = (
        clean_df.set_index("order_date")
        .resample("W-MON")
        .agg(revenue=("total_amount", "sum"), orders=("order_id", "nunique"), active_customers=("customer_id", "nunique"))
        .reset_index()
        .rename(columns={"order_date": "week_start"})
    )
    weekly["avg_order_value"] = weekly["revenue"] / weekly["orders"].replace(0, np.nan)
    weekly["avg_order_value"] = weekly["avg_order_value"].fillna(0)
    return monthly, weekly


def executive_metrics(clean_df: pd.DataFrame, rfm: pd.DataFrame, products: pd.DataFrame) -> dict:
    segment_counts = rfm["segment"].value_counts().to_dict()
    category_revenue = clean_df.groupby("category")["total_amount"].sum().sort_values(ascending=False)
    return {
        "total_revenue": round(float(clean_df["total_amount"].sum()), 2),
        "total_orders": int(clean_df["order_id"].nunique()),
        "total_customers": int(clean_df["customer_id"].nunique()),
        "avg_order_value": round(float(clean_df["total_amount"].sum() / clean_df["order_id"].nunique()), 2),
        "top_category": str(category_revenue.index[0]),
        "top_category_revenue": round(float(category_revenue.iloc[0]), 2),
        "top_product": str(products.iloc[0]["product_name"]),
        "top_product_revenue": round(float(products.iloc[0]["revenue"]), 2),
        "champion_customers": int(segment_counts.get("Champions", 0)),
        "at_risk_high_value_customers": int(segment_counts.get("At-Risk High Value", 0)),
    }
