from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
MODELS_DIR = PROJECT_ROOT / "models"
SQL_DIR = PROJECT_ROOT / "sql"

RAW_TRANSACTIONS_PATH = RAW_DIR / "ecommerce_transactions_raw.csv"
CLEAN_TRANSACTIONS_PATH = PROCESSED_DIR / "ecommerce_cleaned.csv"
DATABASE_PATH = PROCESSED_DIR / "ecommerce.sqlite"
SUMMARY_JSON_PATH = REPORTS_DIR / "analytics_summary.json"
EXECUTIVE_REPORT_PATH = REPORTS_DIR / "executive_summary.html"


def ensure_directories() -> None:
    for path in [RAW_DIR, PROCESSED_DIR, REPORTS_DIR, FIGURES_DIR, MODELS_DIR, SQL_DIR]:
        path.mkdir(parents=True, exist_ok=True)

