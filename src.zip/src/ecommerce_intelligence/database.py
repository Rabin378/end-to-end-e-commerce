from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd


def write_sqlite_database(clean_df: pd.DataFrame, database_path: Path) -> None:
    database_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(database_path) as conn:
        clean_df.to_sql("transactions", conn, if_exists="replace", index=False)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_customer ON transactions(customer_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_product ON transactions(product_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(order_date)")


def query(database_path: Path, sql: str) -> pd.DataFrame:
    with sqlite3.connect(database_path) as conn:
        return pd.read_sql_query(sql, conn)


def run_named_queries(database_path: Path) -> dict[str, pd.DataFrame]:
    queries = {
        "top_products": """
            SELECT product_id, product_name, category,
                   SUM(total_amount) AS revenue,
                   SUM(quantity) AS units_sold,
                   COUNT(DISTINCT order_id) AS orders
            FROM transactions
            GROUP BY product_id, product_name, category
            ORDER BY revenue DESC
            LIMIT 20
        """,
        "top_customers": """
            SELECT customer_id, customer_name, country,
                   COUNT(DISTINCT order_id) AS orders,
                   SUM(total_amount) AS lifetime_value,
                   AVG(total_amount) AS avg_order_value,
                   MAX(order_date) AS last_order_date
            FROM transactions
            GROUP BY customer_id, customer_name, country
            ORDER BY lifetime_value DESC
            LIMIT 20
        """,
        "monthly_sales": """
            SELECT year_month AS sales_month,
                   SUM(total_amount) AS revenue,
                   COUNT(DISTINCT order_id) AS orders,
                   COUNT(DISTINCT customer_id) AS active_customers
            FROM transactions
            GROUP BY year_month
            ORDER BY year_month
        """,
        "weekly_sales": """
            SELECT year_week AS sales_week,
                   MIN(order_date) AS week_start_sample,
                   SUM(total_amount) AS revenue,
                   COUNT(DISTINCT order_id) AS orders
            FROM transactions
            GROUP BY year_week
            ORDER BY sales_week
        """,
    }
    return {name: query(database_path, sql) for name, sql in queries.items()}

