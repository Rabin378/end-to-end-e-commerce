from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class SyntheticDataSpec:
    customers: int = 650
    products: int = 90
    orders: int = 7200
    start_date: str = "2023-01-01"
    end_date: str = "2025-12-31"
    random_seed: int = 42


def make_customers(spec: SyntheticDataSpec) -> pd.DataFrame:
    rng = np.random.default_rng(spec.random_seed)
    countries = np.array(["United States", "Canada", "United Kingdom", "Germany", "Australia", "South Korea"])
    segments = np.array(["retail", "small_business", "enterprise", "marketplace"])
    acquisition = np.array(["paid_search", "organic", "email", "social", "referral", "affiliate"])

    created_dates = pd.to_datetime(spec.start_date) + pd.to_timedelta(
        rng.integers(0, 560, size=spec.customers), unit="D"
    )
    return pd.DataFrame(
        {
            "customer_id": [f"C{idx:05d}" for idx in range(1, spec.customers + 1)],
            "customer_name": [f"Customer {idx:05d}" for idx in range(1, spec.customers + 1)],
            "country": rng.choice(countries, size=spec.customers, p=[0.48, 0.13, 0.14, 0.09, 0.08, 0.08]),
            "customer_type": rng.choice(segments, size=spec.customers, p=[0.72, 0.16, 0.05, 0.07]),
            "acquisition_channel": rng.choice(acquisition, size=spec.customers),
            "customer_since": created_dates,
        }
    )


def make_products(spec: SyntheticDataSpec) -> pd.DataFrame:
    rng = np.random.default_rng(spec.random_seed + 1)
    categories = {
        "Electronics": (55, 900),
        "Home": (18, 360),
        "Beauty": (9, 140),
        "Apparel": (14, 220),
        "Sports": (22, 420),
        "Office": (6, 180),
    }
    rows = []
    category_names = list(categories)
    for idx in range(1, spec.products + 1):
        category = rng.choice(category_names, p=[0.25, 0.19, 0.15, 0.17, 0.13, 0.11])
        low, high = categories[category]
        price = round(float(rng.lognormal(mean=np.log((low + high) / 3), sigma=0.45)), 2)
        price = float(np.clip(price, low, high))
        rows.append(
            {
                "product_id": f"P{idx:04d}",
                "product_name": f"{category} Item {idx:04d}",
                "category": category,
                "unit_price": price,
            }
        )
    return pd.DataFrame(rows)


def make_transactions(spec: SyntheticDataSpec) -> pd.DataFrame:
    rng = np.random.default_rng(spec.random_seed + 2)
    customers = make_customers(spec)
    products = make_products(spec)

    customer_weights = rng.pareto(a=2.0, size=spec.customers) + 0.2
    customer_weights = customer_weights / customer_weights.sum()

    product_weights = rng.pareto(a=1.7, size=spec.products) + 0.3
    product_weights = product_weights / product_weights.sum()

    start = pd.Timestamp(spec.start_date)
    end = pd.Timestamp(spec.end_date)
    day_span = (end - start).days
    order_dates = start + pd.to_timedelta(rng.integers(0, day_span + 1, size=spec.orders), unit="D")

    seasonality = 1 + 0.25 * np.sin((order_dates.dayofyear.to_numpy() / 365) * 2 * np.pi)
    holiday_boost = np.where(np.isin(order_dates.month.to_numpy(), [11, 12]), 1.35, 1.0)

    chosen_customers = customers.iloc[rng.choice(customers.index, size=spec.orders, p=customer_weights)].reset_index(drop=True)
    chosen_products = products.iloc[rng.choice(products.index, size=spec.orders, p=product_weights)].reset_index(drop=True)

    quantity_lambda = np.clip(1.6 * seasonality * holiday_boost, 1.0, 3.6)
    quantities = rng.poisson(quantity_lambda) + 1
    discount = rng.choice([0.0, 0.05, 0.1, 0.15, 0.25], size=spec.orders, p=[0.62, 0.14, 0.12, 0.08, 0.04])

    df = pd.DataFrame(
        {
            "order_id": [f"O{idx:07d}" for idx in range(1, spec.orders + 1)],
            "order_date": order_dates,
            "customer_id": chosen_customers["customer_id"],
            "customer_name": chosen_customers["customer_name"],
            "country": chosen_customers["country"],
            "customer_type": chosen_customers["customer_type"],
            "acquisition_channel": chosen_customers["acquisition_channel"],
            "product_id": chosen_products["product_id"],
            "product_name": chosen_products["product_name"],
            "category": chosen_products["category"],
            "unit_price": chosen_products["unit_price"],
            "quantity": quantities,
            "discount_rate": discount,
            "payment_method": rng.choice(["card", "paypal", "bank_transfer", "wallet"], size=spec.orders),
            "order_status": rng.choice(["completed", "completed", "completed", "returned", "cancelled"], size=spec.orders),
        }
    )
    df["total_amount"] = (df["unit_price"] * df["quantity"] * (1 - df["discount_rate"])).round(2)

    return add_messiness(df, rng)


def add_messiness(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    messy = df.copy()

    duplicate_rows = messy.sample(frac=0.012, random_state=11)
    messy = pd.concat([messy, duplicate_rows], ignore_index=True)

    missing_price_idx = rng.choice(messy.index, size=max(1, int(len(messy) * 0.01)), replace=False)
    missing_quantity_idx = rng.choice(messy.index, size=max(1, int(len(messy) * 0.007)), replace=False)
    bad_quantity_idx = rng.choice(messy.index, size=max(1, int(len(messy) * 0.004)), replace=False)
    future_date_idx = rng.choice(messy.index, size=max(1, int(len(messy) * 0.003)), replace=False)

    messy.loc[missing_price_idx, "unit_price"] = np.nan
    messy.loc[missing_quantity_idx, "quantity"] = np.nan
    messy.loc[bad_quantity_idx, "quantity"] = -1
    messy.loc[future_date_idx, "order_date"] = pd.Timestamp("2026-12-31")

    return messy.sample(frac=1, random_state=23).reset_index(drop=True)
